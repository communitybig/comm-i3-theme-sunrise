# Credits
Xfwm4 themes base on [Default-theme](https://gitlab.xfce.org/Dridi/xfwm4/-/tree/master/themes/default) </br>
License : [GPLv3](https://choosealicense.com/licenses/gpl-3.0/)</br>

# Installation
Extract archive files in directory /.themes, /.local/share/themes or /usr/share/themes (as root)</br>
Test on : </br>
- Debian 10 ( Xfce 12.4 )</br>
- Debian 11 ( Xfce 4.16 )</br>

# Change themes
Xfce4 : Window Manager > Style </br>
